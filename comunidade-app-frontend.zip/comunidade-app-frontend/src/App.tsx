
import React from 'react'
import { Routes, Route, Navigate, Link } from 'react-router-dom'
import Rules from './pages/Rules'
import Home from './pages/Home'
import Groups from './pages/Groups'
import Profile from './pages/Profile'
import GroupPage from './pages/GroupPage/GroupPage'

export default function App() {
  return (
    <div style={{ fontFamily: 'system-ui, Arial', maxWidth: 980, margin: '0 auto', padding: 16 }}>
      <header style={{ display: 'flex', gap: 12, alignItems: 'center', justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0 }}>Comunidades</h2>
        <nav style={{ display: 'flex', gap: 10 }}>
          <Link to="/home">Início</Link>
          <Link to="/groups">Grupos</Link>
          <Link to="/rules">Regras</Link>
          <Link to="/profile">Perfil</Link>
        </nav>
      </header>
      <hr />
      <Routes>
        <Route path="/" element={<Navigate to="/rules" replace />} />
        <Route path="/rules" element={<Rules />} />
        <Route path="/home" element={<Home />} />
        <Route path="/groups" element={<Groups />} />
        <Route path="/groups/:id" element={<GroupPage />} />
        <Route path="/profile" element={<Profile />} />
      </Routes>
    </div>
  )
}
