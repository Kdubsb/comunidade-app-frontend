
import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabase'

export default function Rules() {
  const [policy, setPolicy] = useState<{title:string, body:string} | null>(null)

  useEffect(() => {
    supabase.from('usage_policies').select('title, body').order('updated_at', { ascending: false }).limit(1)
      .then(({ data }) => setPolicy(data?.[0] || null))
  }, [])

  return (
    <div>
      <h3>Regras essenciais</h3>
      <p>Leia com atenção antes de usar.</p>
      <pre style={{ whiteSpace: 'pre-wrap', background:'#f9fafb', padding: 12, borderRadius: 8 }}>
        {policy ? `${policy.title}

${policy.body}` : 'Carregando regras...'}
      </pre>
      <p><b>Importante:</b> mensagens do chat são temporárias. Informações importantes ficam em “Informações” e “Encontros”.</p>
    </div>
  )
}
