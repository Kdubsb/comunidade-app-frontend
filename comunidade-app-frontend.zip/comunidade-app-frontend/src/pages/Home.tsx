
import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabase'
import { BannerGlobal } from '../components/BannerGlobal'

export default function Home() {
  const [news, setNews] = useState<any[]>([])
  const [ads, setAds] = useState<any[]>([])

  useEffect(() => {
    supabase.from('ad_global_slots').select('slot, image_url, target_url, label').eq('active', true).order('slot')
      .then(({ data }) => setAds(data || []))
    supabase.from('global_news').select('id, title, body, external_url, published_at').eq('active', true).order('published_at', { ascending: false })
      .then(({ data }) => setNews(data || []))
  }, [])

  return (
    <div>
      <h3>Notícias globais</h3>
      <BannerGlobal slots={[1,2,3].map(s=>ads.find(a=>a.slot===s)||{slot:s})} />
      <div style={{ display: 'grid', gap: 10 }}>
        {news.map(n => (
          <article key={n.id} style={{ border:'1px solid #e5e7eb', borderRadius:8, padding:12 }}>
            <h4 style={{ margin:'0 0 6px 0' }}>{n.title}</h4>
            <div style={{ fontSize: 13, opacity: 0.7 }}>{new Date(n.published_at).toLocaleString('pt-BR')}</div>
            <p style={{ marginTop: 8 }}>{n.body}</p>
            {n.external_url ? <a href={n.external_url} target="_blank" rel="noreferrer">Abrir link</a> : null}
          </article>
        ))}
      </div>
    </div>
  )
}
