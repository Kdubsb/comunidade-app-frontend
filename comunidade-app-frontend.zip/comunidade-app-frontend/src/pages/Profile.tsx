
import React, { useEffect, useState } from 'react'
import { supabase } from '../services/supabase'

export default function Profile() {
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user))
  }, [])

  return (
    <div>
      <h3>Perfil</h3>
      {user ? (
        <div style={{ border:'1px solid #e5e7eb', borderRadius:8, padding:12 }}>
          <div><b>ID:</b> {user.id}</div>
          <div><b>Email:</b> {user.email}</div>
          <p style={{ opacity:0.8 }}>A validação de identidade e o status do usuário aparecem no backend (user_profiles).</p>
        </div>
      ) : (
        <p>Você ainda não está autenticado neste protótipo. Integre o fluxo de login depois.</p>
      )}
    </div>
  )
}
