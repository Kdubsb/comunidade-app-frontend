
import React, { useEffect, useState } from 'react'
import { supabase } from '../../services/supabase'

export default function Info({ groupId }: { groupId: string }) {
  const [posts, setPosts] = useState<any[]>([])

  useEffect(() => {
    supabase.from('group_posts')
      .select('id, title, body, published_at')
      .eq('group_id', groupId)
      .eq('active', true)
      .order('published_at', { ascending: false })
      .then(({ data }) => setPosts(data || []))
  }, [groupId])

  return (
    <div style={{ display:'grid', gap:10 }}>
      {posts.map(p => (
        <article key={p.id} style={{ border:'1px solid #e5e7eb', borderRadius:8, padding:12 }}>
          <h4 style={{ margin:'0 0 6px 0' }}>{p.title}</h4>
          <div style={{ fontSize:12, opacity:0.7 }}>{new Date(p.published_at).toLocaleString('pt-BR')}</div>
          <p style={{ marginTop: 8 }}>{p.body}</p>
        </article>
      ))}
      {posts.length === 0 ? <p>Nenhuma informação publicada ainda.</p> : null}
    </div>
  )
}
