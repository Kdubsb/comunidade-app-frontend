
import React, { useEffect, useState } from 'react'
import { supabase } from '../../services/supabase'

export default function Events({ groupId }: { groupId: string }) {
  const [events, setEvents] = useState<any[]>([])

  useEffect(() => {
    supabase.from('group_events')
      .select('id, title, description, starts_at, location_label, maps_url')
      .eq('group_id', groupId)
      .eq('active', true)
      .order('starts_at', { ascending: true })
      .then(({ data }) => setEvents(data || []))
  }, [groupId])

  return (
    <div style={{ display:'grid', gap:10 }}>
      {events.map(ev => (
        <div key={ev.id} style={{ border:'1px solid #e5e7eb', borderRadius:8, padding:12 }}>
          <b>{ev.title}</b>
          <div style={{ fontSize:12, opacity:0.7 }}>{new Date(ev.starts_at).toLocaleString('pt-BR')}</div>
          <div style={{ marginTop: 6 }}>{ev.description}</div>
          <div style={{ marginTop: 6, opacity:0.85 }}>{ev.location_label}</div>
          {ev.maps_url ? <a href={ev.maps_url} target="_blank" rel="noreferrer">Abrir no Google Maps</a> : null}
        </div>
      ))}
      {events.length === 0 ? <p>Nenhum encontro marcado.</p> : null}
    </div>
  )
}
