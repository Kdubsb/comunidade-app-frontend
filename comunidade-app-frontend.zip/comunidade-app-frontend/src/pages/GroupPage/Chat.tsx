
import React, { useEffect, useRef, useState } from 'react'
import { supabase } from '../../services/supabase'

export default function Chat({ groupId }: { groupId: string }) {
  const [messages, setMessages] = useState<any[]>([])
  const [text, setText] = useState('')
  const channelRef = useRef<any>(null)

  useEffect(() => {
    // Carrega últimas mensagens não expiradas (simples)
    const nowIso = new Date().toISOString()
    supabase.from('group_messages')
      .select('id, body, created_at, user_id')
      .eq('group_id', groupId)
      .gt('expires_at', nowIso)
      .order('created_at', { ascending: false })
      .limit(50)
      .then(({ data }) => setMessages((data || []).reverse()))

    // Realtime (insert)
    channelRef.current = supabase.channel(`chat:${groupId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'group_messages', filter: `group_id=eq.${groupId}` },
        (payload: any) => {
          setMessages(prev => [...prev, payload.new])
        }
      )
      .subscribe()

    return () => {
      if (channelRef.current) supabase.removeChannel(channelRef.current)
    }
  }, [groupId])

  async function send() {
    const body = text.trim()
    if (!body) return
    const { data: auth } = await supabase.auth.getUser()
    const userId = auth.user?.id
    if (!userId) {
      alert('Login será integrado na próxima etapa.');
      return
    }

    // expires_at = now + 48h (no MVP, ler do system_config depois)
    const expires = new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString()
    await supabase.from('group_messages').insert({ group_id: groupId, user_id: userId, body, expires_at: expires })
    setText('')
  }

  return (
    <div>
      <div style={{ fontSize: 12, opacity: 0.7, marginBottom: 8 }}>
        Mensagens são temporárias e desaparecem após o período configurado.
      </div>
      <div style={{ border:'1px solid #e5e7eb', borderRadius:8, padding:12, minHeight: 240 }}>
        {messages.map(m => (
          <div key={m.id} style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 12, opacity: 0.7 }}>{new Date(m.created_at).toLocaleString('pt-BR')}</div>
            <div>{m.body}</div>
          </div>
        ))}
      </div>
      <div style={{ display:'flex', gap:8, marginTop:10 }}>
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="Digite uma mensagem" style={{ flex:1, padding:10, borderRadius:8, border:'1px solid #e5e7eb' }} />
        <button onClick={send}>Enviar</button>
      </div>
    </div>
  )
}
