
import React, { useEffect, useMemo, useState } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../../services/supabase'
import Chat from './Chat'
import Info from './Info'
import Events from './Events'
import { BannerGroup } from '../../components/BannerGroup'
import { EventAlert } from '../../components/EventAlert'

type Tab = 'chat'|'info'|'events'

export default function GroupPage() {
  const { id } = useParams()
  const [group, setGroup] = useState<any>(null)
  const [tab, setTab] = useState<Tab>('chat')
  const [banner, setBanner] = useState<any>(null)
  const [nextEvent, setNextEvent] = useState<any>(null)

  useEffect(() => {
    if (!id) return
    supabase.from('groups').select('id, name, theme, description').eq('id', id).single()
      .then(({ data }) => setGroup(data))
    supabase.from('ad_group_slots').select('image_url, target_url, label').eq('group_id', id).eq('active', true).maybeSingle()
      .then(({ data }) => setBanner(data))

    const nowIso = new Date().toISOString()
    supabase.from('group_events')
      .select('id, title, starts_at')
      .eq('group_id', id)
      .eq('active', true)
      .gt('starts_at', nowIso)
      .order('starts_at', { ascending: true })
      .limit(1)
      .then(({ data }) => setNextEvent(data?.[0] || null))
  }, [id])

  const content = useMemo(() => {
    if (!id) return null
    if (tab === 'chat') return <Chat groupId={id} />
    if (tab === 'info') return <Info groupId={id} />
    return <Events groupId={id} />
  }, [tab, id])

  if (!group) return <p>Carregando grupo...</p>

  return (
    <div>
      <h3 style={{ marginBottom: 4 }}>{group.name}</h3>
      <div style={{ opacity: 0.8 }}>{group.theme} — {group.description}</div>

      <BannerGroup banner={banner} />

      <EventAlert nextEvent={nextEvent} onOpen={() => setTab('events')} />

      <div style={{ display:'flex', gap:8, marginTop:12 }}>
        <button onClick={()=>setTab('chat')} disabled={tab==='chat'}>Chat</button>
        <button onClick={()=>setTab('info')} disabled={tab==='info'}>Informações</button>
        <button onClick={()=>setTab('events')} disabled={tab==='events'}>Encontros</button>
      </div>
      <div style={{ marginTop: 12 }}>{content}</div>

      <hr />
      <a href="#" onClick={(e)=>{e.preventDefault(); alert('Tela de denúncia entra na próxima etapa do MVP.');}}>Denunciar má prática</a>
    </div>
  )
}
