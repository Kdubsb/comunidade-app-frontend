
import React, { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../services/supabase'

export default function Groups() {
  const [q, setQ] = useState('')
  const [groups, setGroups] = useState<any[]>([])

  useEffect(() => {
    supabase.from('groups').select('id, name, theme, description, purpose').eq('status','ativo').order('name')
      .then(({ data }) => setGroups(data || []))
  }, [])

  const filtered = useMemo(() => {
    const qq = q.trim().toLowerCase()
    if (!qq) return groups
    return groups.filter(g =>
      (g.name||'').toLowerCase().includes(qq) ||
      (g.theme||'').toLowerCase().includes(qq)
    )
  }, [q, groups])

  return (
    <div>
      <h3>Grupos</h3>
      <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar por nome ou tema" style={{ width:'100%', padding:10, borderRadius:8, border:'1px solid #e5e7eb' }} />
      <div style={{ display:'grid', gap:10, marginTop:12 }}>
        {filtered.map(g => (
          <div key={g.id} style={{ border:'1px solid #e5e7eb', borderRadius:8, padding:12 }}>
            <div style={{ display:'flex', justifyContent:'space-between', gap:10 }}>
              <div>
                <b>{g.name}</b> <span style={{ fontSize:12, opacity:0.7 }}>({g.theme})</span>
                {g.purpose === 'comercial' ? <span style={{ marginLeft:8, fontSize:12, color:'#7c2d12', background:'#ffedd5', padding:'2px 6px', borderRadius:999 }}>comercial</span> : null}
                <div style={{ marginTop:6, fontSize:14 }}>{g.description}</div>
              </div>
              <Link to={`/groups/${g.id}`}>Ver grupo</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
