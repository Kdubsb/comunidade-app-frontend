
import React from 'react'

export function BannerGlobal({ slots }: { slots: Array<{slot:number, image_url?:string, target_url?:string, label?:string}> }) {
  return (
    <div style={{ display: 'grid', gap: 8, marginBottom: 12 }}>
      {slots.map(s => (
        <a key={s.slot} href={s.target_url || '#'} target="_blank" rel="noreferrer"
           style={{ display: 'block', border: '1px solid #e5e7eb', padding: 10, borderRadius: 8, textDecoration: 'none' }}>
          <div style={{ fontSize: 12, opacity: 0.7 }}>{s.label || 'Patrocinador'}</div>
          <div style={{ fontSize: 14 }}>{s.image_url ? `Imagem: ${s.image_url}` : 'Espaço disponível'}</div>
        </a>
      ))}
    </div>
  )
}
