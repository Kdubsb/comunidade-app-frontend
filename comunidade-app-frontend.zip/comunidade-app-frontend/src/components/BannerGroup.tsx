
import React from 'react'

export function BannerGroup({ banner }: { banner?: { image_url?: string, target_url?: string, label?: string } }) {
  if (!banner) return null
  return (
    <a href={banner.target_url || '#'} target="_blank" rel="noreferrer"
       style={{ display: 'block', border: '1px solid #e5e7eb', padding: 10, borderRadius: 8, textDecoration: 'none', margin: '10px 0' }}>
      <div style={{ fontSize: 12, opacity: 0.7 }}>{banner.label || 'Apoio ao grupo'}</div>
      <div style={{ fontSize: 14 }}>{banner.image_url ? `Imagem: ${banner.image_url}` : 'Banner do grupo'}</div>
    </a>
  )
}
