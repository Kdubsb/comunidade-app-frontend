
import React from 'react'

export function EventAlert({ nextEvent, onOpen }: { nextEvent?: {title:string, starts_at:string}, onOpen: () => void }) {
  if (!nextEvent) return null
  return (
    <div style={{ background: '#fff7ed', border: '1px solid #fed7aa', padding: 10, borderRadius: 8, marginTop: 10 }}>
      <strong>⚠️ Atenção: evento marcado</strong>
      <div style={{ fontSize: 14, marginTop: 4 }}>
        Próximo: {nextEvent.title} — {new Date(nextEvent.starts_at).toLocaleString('pt-BR')}
      </div>
      <button onClick={onOpen} style={{ marginTop: 8 }}>Ver detalhes</button>
    </div>
  )
}
