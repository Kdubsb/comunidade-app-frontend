
# Frontend — Plataforma de Comunidades (MVP)

PWA (web app instalável) com:
- Notícias globais
- Busca e acesso a grupos
- Chat em tempo real (mensagens efêmeras)
- Informações e encontros por grupo
- Banners estáticos (global e por grupo)

## Stack
- React + Vite + TypeScript
- supabase-js
- PWA

## Execução local
1. `npm install`
2. Copie `.env.example` para `.env` e preencha as variáveis
3. `npm run dev`

## Deploy
- Recomendado: Vercel.

